package com.example.texttospeech

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.text.TextUtils
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var ts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ts = TextToSpeech(this,TextToSpeech.OnInitListener {
            status ->
            if (status != TextToSpeech.ERROR) {
                ts.language = Locale.UK
            }
        })
        btnSpeech.setOnClickListener {
            var sp = txtSpeech.text.toString()
            if(TextUtils.isEmpty(sp)) {
                txtSpeech.error = "This field is Required"
                txtSpeech.requestFocus()
            }
            else {
                ts.speak(sp,TextToSpeech.QUEUE_FLUSH,null)
                Toast.makeText(this,sp,Toast.LENGTH_SHORT).show()
            }
        }
    }
}
